<?php

require 'vendor/autoload.php';
use msimenic_20\Kava;
use msimenic_20\Pomocno;

Flight::route('GET /v3/kava', function(){
   $doctrineBootstrap = Flight::db();
   $em = $doctrineBootstrap->getEntityManager();
   $repozitorij=$em->getRepository('msimenic_20\Kava');
   $kava = $repozitorij->findAll();
   $podaci = $doctrineBootstrap->getJson($kava);
   Flight::json(Pomocno::odgovor(false,'OK',json_decode($podaci)));

});



Flight::route('POST /v3/kava', function(){
  if(strlen(Flight::request()->data->proizvodac)===0){

    Flight::json(Pomocno::odgovor(true,'Proizvođač obavezan',null));
    return;
  }
  if(strlen(Flight::request()->data->kolicina)===0){
    Flight::json(Pomocno::odgovor(true,'Količina obavezna',null));
    return;
  
  }
  if(strlen(Flight::request()->data->datum)===0){

    Flight::json(Pomocno::odgovor(true,'Datum obavezan',null));
    return;
  }
  $kava = new Kava(Flight::request()->data);
  $doctrineBootstrap = Flight::db();
  $em = $doctrineBootstrap->getEntityManager();
  $em->persist($kava);
  $em->flush();
  $podaci = $doctrineBootstrap->getJson($kava);
  Flight::json(Pomocno::odgovor(false,'OK',[json_decode($podaci)]));
  header("HTTP/1.1 201 Created");
});



Flight::route('PUT /v3/kava/@sifra', function($sifra){ 
    $doctrineBootstrap = Flight::db();
    $em = $doctrineBootstrap->getEntityManager();
    $repozitorij=$em->getRepository('msimenic_20\Kava');
    $kava = $repozitorij->find($sifra);
    $kava->setProizvodac(Flight::request()->data->proizvodac);
    $kava->setKolicina(Flight::request()->data->kolicina);
    $kava->setDatum(Flight::request()->data->datum);
    
    $em->persist($kava);
    $em->flush();
    Flight::json(Pomocno::odgovor(false,'OK',null));
  });

  Flight::route('DELETE /v3/kava/@sifra', function($sifra){
    $doctrineBootstrap = Flight::db();
    $em = $doctrineBootstrap->getEntityManager();
    $repozitorij=$em->getRepository('msimenic_20\Kava');
    $kava = $repozitorij->find($sifra);
    $em->remove($kava);
    $em->flush();
    Flight::json(Pomocno::odgovor(false,'OK',[$kava]));
  });

Flight::route('/', function(){
  Flight::json(Pomocno::odgovor(true,'nepotpuni podaci'));
});

Flight::map('notFound', function(){
  Flight::json(Pomocno::odgovor(true,'nepotpuni podaci'));
});

require_once 'bootstrap.php';

Flight::register('db','DoctrineBootstrap');

Flight::start();