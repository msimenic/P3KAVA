<?php
namespace msimenic_20;

/**
 * @Entity @Table(name="kava")
 **/
class Kava
{
    /** @Id @Column(type="integer") @GeneratedValue  **/
	private $sifra;


    /** @Column(type="string") **/
	private $proizvodac;


    /** @Column(type="integer") @GeneratedValue  **/
	private $kolicina;

   /** @Column(type="date") @GeneratedValue  **/
   private $datum;
	
	public function __construct($podaci=null)
	{
		if($podaci==null){
			return;
		}
		$this->sifra=$podaci->sifra;
		$this->proizvodac=$podaci->proizvodac;
		$this->kolicina=$podaci->kolicina;
		$this->datum=$podaci->datum;


	}

	public function getSifra(){
		return $this->sifra;
	}

	public function setSifra($sifra){
		$this->sifra = $sifra;
	}

	public function getProizvodac(){
		return $this->proizvodac;
	}

	public function setProizvodac($proizvodac){
		$this->proizvodac = $proizvodac;
	}

	public function getKolicina(){
		return $this->kolicina;
	}

	public function setKolicina($kolicina){
		$this->kolicina = $kolicina;
	}

	public function getDatum(){
		return $this->datum;
	}

	public function setDatum($datum){
		$this->datum = $datum;
	}

}