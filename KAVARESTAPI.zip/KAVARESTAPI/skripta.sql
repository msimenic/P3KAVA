create database msimenic_20_20 default character set utf8mb4;
use msimenic_20_20;
create table kava(
    sifra int not null primary key auto_increment,
    proizvodac varchar(255) not null,
    kolicina int not null,
    datum date not null
    
);
insert into kava(proizvodac, kolicina, datum)
values ('Franck', 345, '2021-09-07');
